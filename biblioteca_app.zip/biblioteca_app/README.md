# Biblioteca Escolar — Fase 3 (interfaces, navegación, formularios y estado)

Aplicación Flutter para llevar el control de préstamos de libros de la
biblioteca escolar. Usa las mismas interfaces de la Fase 2, ahora
funcionales: navegación entre pantallas, formularios con validación, estado
compartido y diseño que se adapta al ancho de la pantalla.

Los datos son de ejemplo y viven en memoria (no hay base de datos): se
reinician al cerrar la app.

## Cómo ejecutarla
Copie `lib/`, `test/` y `pubspec.yaml` a un proyecto creado con
`flutter create .` (en una ruta sin tildes ni caracteres especiales), y luego:

    flutter pub get
    flutter run -d <dispositivo>
    flutter test

## Qué pide la guía y dónde está

| Requisito | Dónde |
|---|---|
| Pantalla principal | `screens/home_screen.dart` |
| Mínimo 3 pantallas funcionales | Catálogo, Estudiantes, Préstamos, Historial y Notificaciones |
| Menú o navegación | Menú de la pantalla principal + `Navigator.push` y botón atrás |
| Formularios de captura | Libro, estudiante y préstamo (`Form` + `TextFormField`) |
| Validación básica | `utils/validadores.dart` (obligatorio, mínimo, número, correo, código repetido) |
| Gestión básica de estado | `state/app_state.dart` (`ChangeNotifier` + `InheritedNotifier`) |
| Diseño responsivo | `ContenidoCentrado` (ancho máximo) y menú en 1 o 2 columnas según el ancho |
| Reutilización de componentes | `widgets/` |
| Diseño visual coherente | `theme/app_tema.dart` (paleta y tema únicos) |

## Estructura
    lib/
    ├── main.dart                  Arranque, tema, idioma y estado de la app
    ├── theme/app_tema.dart        Colores (índigo) y tema Material 3
    ├── state/app_state.dart       AppState (ChangeNotifier) y EstadoApp
    ├── models/                    Libro, Estudiante, Prestamo
    ├── data/datos_ejemplo.dart    Datos con los que arranca la app
    ├── utils/                     formato.dart, validadores.dart
    ├── widgets/                   Componentes reutilizables
    │   ├── barra_degradada.dart   Barra superior con degradado
    │   ├── tarjeta.dart           Tarjeta blanca con sombra
    │   ├── caja_icono.dart        Icono en recuadro de color
    │   ├── panel_datos.dart       Recuadro con 3 datos en columnas
    │   ├── contenido_centrado.dart Ancho máximo (diseño responsivo)
    │   └── estado_chip.dart       Etiqueta de estado
    └── screens/                   Una pantalla por archivo
    test/                          Validadores, estado y navegación

## Cómo fluye la información
    Formulario ──► AppState.agregarLibro() ──► notifyListeners()
                                                   │
        Catálogo, Préstamos, Notificaciones ◄──────┘  (se redibujan solas)
