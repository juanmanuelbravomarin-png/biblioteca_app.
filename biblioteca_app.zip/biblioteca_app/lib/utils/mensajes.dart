import 'package:flutter/material.dart';

/// Muestra un mensaje breve en la parte inferior (SnackBar).
/// Si [error] es true usa los colores de error del tema.
void mostrarMensaje(BuildContext context, String texto, {bool error = false}) {
  final esquema = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: error ? esquema.error : null,
        content: Text(
          texto,
          style: error ? TextStyle(color: esquema.onError) : null,
        ),
      ),
    );
}

/// Diálogo de confirmación. Devuelve true solo si el usuario acepta.
Future<bool> confirmar(
  BuildContext context, {
  required String titulo,
  required String mensaje,
  String textoConfirmar = 'Aceptar',
}) async {
  final respuesta = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(titulo),
      content: Text(mensaje),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(textoConfirmar),
        ),
      ],
    ),
  );
  return respuesta ?? false;
}

/// True si el error viene de una restricción UNIQUE de SQLite
/// (por ejemplo, un código de libro o un documento repetido).
bool esErrorUnico(Object error) => error.toString().toUpperCase().contains('UNIQUE');
