import 'package:sqflite/sqflite.dart';

import '../models/estudiante.dart';
import 'database_helper.dart';
import 'libro_dao.dart' show EliminacionNoPermitida;

/// Operaciones CRUD sobre la tabla `estudiantes`.
class EstudianteDao {
  static const _tabla = 'estudiantes';

  Future<Database> get _bd async => DatabaseHelper.instancia.database;

  // ---------------------------------------------------------------- CREATE
  Future<int> insertar(Estudiante estudiante) async {
    final db = await _bd;
    return db.insert(
      _tabla,
      estudiante.toMap(),
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  // ------------------------------------------------------------------ READ
  Future<List<Estudiante>> listar({String? busqueda}) async {
    final db = await _bd;
    final texto = busqueda?.trim() ?? '';

    final filas = await db.query(
      _tabla,
      where: texto.isEmpty ? null : '(nombre LIKE ? OR documento LIKE ?)',
      whereArgs: texto.isEmpty ? null : ['%$texto%', '%$texto%'],
      orderBy: 'nombre COLLATE NOCASE ASC',
    );
    return filas.map(Estudiante.fromMap).toList();
  }

  Future<Estudiante?> obtenerPorId(int id) async {
    final db = await _bd;
    final filas =
        await db.query(_tabla, where: 'id = ?', whereArgs: [id], limit: 1);
    return filas.isEmpty ? null : Estudiante.fromMap(filas.first);
  }

  Future<int> contar() async {
    final db = await _bd;
    final r = await db.rawQuery('SELECT COUNT(*) AS total FROM $_tabla');
    return Sqflite.firstIntValue(r) ?? 0;
  }

  // ---------------------------------------------------------------- UPDATE
  Future<int> actualizar(Estudiante estudiante) async {
    assert(estudiante.id != null);
    final db = await _bd;
    return db.update(
      _tabla,
      estudiante.toMap(),
      where: 'id = ?',
      whereArgs: [estudiante.id],
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  // ---------------------------------------------------------------- DELETE
  Future<int> eliminar(int id) async {
    final db = await _bd;
    final activos = Sqflite.firstIntValue(await db.rawQuery(
          'SELECT COUNT(*) FROM prestamos WHERE estudiante_id = ? AND estado = ?',
          [id, 'activo'],
        )) ??
        0;

    if (activos > 0) {
      throw EliminacionNoPermitida(
        'No se puede eliminar: el estudiante tiene $activos préstamo(s) sin devolver.',
      );
    }

    return db.delete(_tabla, where: 'id = ?', whereArgs: [id]);
  }
}
