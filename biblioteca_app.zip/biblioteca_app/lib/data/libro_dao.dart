import 'package:sqflite/sqflite.dart';

import '../models/libro.dart';
import 'database_helper.dart';

/// Filtro de disponibilidad para la búsqueda del catálogo (RF02).
enum FiltroDisponibilidad { todos, disponibles, prestados }

/// Operaciones CRUD sobre la tabla `libros` (RF01, RF02, RF07).
class LibroDao {
  static const _tabla = 'libros';

  Future<Database> get _bd async => DatabaseHelper.instancia.database;

  // ---------------------------------------------------------------- CREATE
  /// Inserta un libro y devuelve el id generado.
  /// Lanza [DatabaseException] si el código ya existe (columna UNIQUE).
  Future<int> insertar(Libro libro) async {
    final db = await _bd;
    return db.insert(
      _tabla,
      libro.copyWith(ejemplaresDisponibles: libro.ejemplaresTotal).toMap(),
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  // ------------------------------------------------------------------ READ
  /// Lista el catálogo, opcionalmente filtrado por texto y disponibilidad.
  Future<List<Libro>> listar({
    String? busqueda,
    FiltroDisponibilidad filtro = FiltroDisponibilidad.todos,
  }) async {
    final db = await _bd;

    final condiciones = <String>[];
    final argumentos = <Object?>[];

    final texto = busqueda?.trim() ?? '';
    if (texto.isNotEmpty) {
      condiciones.add('(titulo LIKE ? OR autor LIKE ? OR codigo LIKE ?)');
      final patron = '%$texto%';
      argumentos.addAll([patron, patron, patron]);
    }

    switch (filtro) {
      case FiltroDisponibilidad.disponibles:
        condiciones.add('ejemplares_disponibles > 0');
        break;
      case FiltroDisponibilidad.prestados:
        condiciones.add('ejemplares_disponibles = 0');
        break;
      case FiltroDisponibilidad.todos:
        break;
    }

    final filas = await db.query(
      _tabla,
      where: condiciones.isEmpty ? null : condiciones.join(' AND '),
      whereArgs: argumentos.isEmpty ? null : argumentos,
      orderBy: 'titulo COLLATE NOCASE ASC',
    );
    return filas.map(Libro.fromMap).toList();
  }

  Future<Libro?> obtenerPorId(int id) async {
    final db = await _bd;
    final filas = await db.query(
      _tabla,
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return filas.isEmpty ? null : Libro.fromMap(filas.first);
  }

  Future<Libro?> obtenerPorCodigo(String codigo) async {
    final db = await _bd;
    final filas = await db.query(
      _tabla,
      where: 'codigo = ?',
      whereArgs: [codigo],
      limit: 1,
    );
    return filas.isEmpty ? null : Libro.fromMap(filas.first);
  }

  Future<int> contar() async {
    final db = await _bd;
    final r = await db.rawQuery('SELECT COUNT(*) AS total FROM $_tabla');
    return Sqflite.firstIntValue(r) ?? 0;
  }

  /// Suma de ejemplares que están en la biblioteca y se pueden prestar.
  Future<int> totalEjemplaresDisponibles() async {
    final db = await _bd;
    final r = await db.rawQuery(
      'SELECT COALESCE(SUM(ejemplares_disponibles), 0) FROM $_tabla',
    );
    return Sqflite.firstIntValue(r) ?? 0;
  }

  // ---------------------------------------------------------------- UPDATE
  /// Actualiza un libro existente. Devuelve el número de filas afectadas.
  Future<int> actualizar(Libro libro) async {
    assert(libro.id != null, 'El libro debe tener id para poder actualizarse');
    final db = await _bd;
    return db.update(
      _tabla,
      libro.toMap(),
      where: 'id = ?',
      whereArgs: [libro.id],
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  // ---------------------------------------------------------------- DELETE
  /// Elimina un libro. Devuelve las filas eliminadas.
  ///
  /// Si el libro tiene préstamos activos no se elimina y se lanza
  /// [EliminacionNoPermitida], para no dejar registros huérfanos.
  Future<int> eliminar(int id) async {
    final db = await _bd;
    final activos = Sqflite.firstIntValue(await db.rawQuery(
          'SELECT COUNT(*) FROM prestamos WHERE libro_id = ? AND estado = ?',
          [id, 'activo'],
        )) ??
        0;

    if (activos > 0) {
      throw EliminacionNoPermitida(
        'No se puede eliminar: el libro tiene $activos préstamo(s) sin devolver.',
      );
    }

    return db.delete(_tabla, where: 'id = ?', whereArgs: [id]);
  }
}

/// Error de negocio para operaciones bloqueadas por integridad de datos.
class EliminacionNoPermitida implements Exception {
  final String mensaje;
  EliminacionNoPermitida(this.mensaje);
  @override
  String toString() => mensaje;
}
