import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Acceso único a la base de datos local SQLite (RF08).
///
/// Se usa el patrón Singleton para que toda la app comparta una sola
/// conexión abierta.
class DatabaseHelper {
  DatabaseHelper._interno();
  static final DatabaseHelper instancia = DatabaseHelper._interno();

  static const _nombreBd = 'biblioteca.db';
  static const _version = 1;

  Database? _bd;

  Future<Database> get database async {
    _bd ??= await _abrirBd();
    return _bd!;
  }

  Future<Database> _abrirBd() async {
    final ruta = p.join(await getDatabasesPath(), _nombreBd);
    return openDatabase(
      ruta,
      version: _version,
      onConfigure: (db) async {
        // Sin esto SQLite ignora las llaves foráneas.
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _crearTablas,
      onUpgrade: _actualizarEsquema,
    );
  }

  Future<void> _crearTablas(Database db, int version) async {
    await db.execute('''
      CREATE TABLE libros (
        id                     INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo                 TEXT    NOT NULL UNIQUE,
        titulo                 TEXT    NOT NULL,
        autor                  TEXT    NOT NULL,
        categoria              TEXT    NOT NULL DEFAULT 'General',
        ejemplares_total       INTEGER NOT NULL DEFAULT 1,
        ejemplares_disponibles INTEGER NOT NULL DEFAULT 1,
        portada_path           TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE estudiantes (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        documento TEXT    NOT NULL UNIQUE,
        nombre    TEXT    NOT NULL,
        grado     TEXT    NOT NULL DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE prestamos (
        id                    INTEGER PRIMARY KEY AUTOINCREMENT,
        libro_id              INTEGER NOT NULL,
        estudiante_id         INTEGER NOT NULL,
        fecha_prestamo        TEXT    NOT NULL,
        fecha_devolucion_max  TEXT    NOT NULL,
        fecha_devolucion_real TEXT,
        estado                TEXT    NOT NULL DEFAULT 'activo',
        FOREIGN KEY (libro_id)      REFERENCES libros (id)      ON DELETE RESTRICT,
        FOREIGN KEY (estudiante_id) REFERENCES estudiantes (id) ON DELETE RESTRICT
      )
    ''');

    // Índices para que la búsqueda del RF02 y el historial del RF05
    // sigan siendo rápidos cuando crezca el catálogo.
    await db.execute('CREATE INDEX idx_libros_titulo ON libros (titulo)');
    await db.execute('CREATE INDEX idx_libros_autor ON libros (autor)');
    await db.execute(
        'CREATE INDEX idx_prestamos_estado ON prestamos (estado, fecha_devolucion_max)');
    await db
        .execute('CREATE INDEX idx_prestamos_libro ON prestamos (libro_id)');
    await db.execute(
        'CREATE INDEX idx_prestamos_estudiante ON prestamos (estudiante_id)');

    await _insertarDatosDePrueba(db);
  }

  /// Migraciones para futuras versiones del esquema.
  Future<void> _actualizarEsquema(
      Database db, int versionAnterior, int versionNueva) async {
    // Ejemplo para la versión 2:
    // if (versionAnterior < 2) {
    //   await db.execute('ALTER TABLE libros ADD COLUMN editorial TEXT');
    // }
  }

  Future<void> _insertarDatosDePrueba(Database db) async {
    final lote = db.batch();
    lote.insert('libros', {
      'codigo': 'LIT-001',
      'titulo': 'La vuelta al mundo en 80 días',
      'autor': 'Julio Verne',
      'categoria': 'Literatura',
      'ejemplares_total': 3,
      'ejemplares_disponibles': 3,
    });
    lote.insert('libros', {
      'codigo': 'CIE-014',
      'titulo': 'Ciencias Naturales 2',
      'autor': 'MEN Colombia',
      'categoria': 'Ciencias',
      'ejemplares_total': 5,
      'ejemplares_disponibles': 5,
    });
    lote.insert('estudiantes', {
      'documento': '1090123456',
      'nombre': 'María Fernanda Rojas',
      'grado': '2-A',
    });
    lote.insert('estudiantes', {
      'documento': '1090987654',
      'nombre': 'Juan David Peñaranda',
      'grado': '2-A',
    });
    await lote.commit(noResult: true);
  }

  Future<void> cerrar() async {
    await _bd?.close();
    _bd = null;
  }
}
