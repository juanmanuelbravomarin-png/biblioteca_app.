import 'package:sqflite/sqflite.dart';

import '../models/prestamo.dart';
import 'database_helper.dart';
import 'libro_dao.dart' show EliminacionNoPermitida;

/// Operaciones sobre la tabla `prestamos` (RF03, RF04, RF05, RF06).
class PrestamoDao {
  static const _tabla = 'prestamos';

  /// Consulta base que cruza préstamo + libro + estudiante.
  static const _consultaDetalle = '''
    SELECT p.*, l.titulo, l.codigo, e.nombre, e.grado
    FROM prestamos p
    INNER JOIN libros l      ON l.id = p.libro_id
    INNER JOIN estudiantes e ON e.id = p.estudiante_id
  ''';

  Future<Database> get _bd async => DatabaseHelper.instancia.database;

  // ---------------------------------------------------------------- CREATE
  /// Registra un préstamo y descuenta un ejemplar disponible (RF03 + RF04).
  ///
  /// Ambas escrituras van dentro de una transacción: si algo falla, la base
  /// no queda con un préstamo registrado y el inventario sin actualizar.
  Future<int> registrarPrestamo({
    required int libroId,
    required int estudianteId,
    int diasPlazo = 8,
    DateTime? fechaPrestamo,
  }) async {
    final db = await _bd;
    final inicio = fechaPrestamo ?? DateTime.now();

    return db.transaction<int>((txn) async {
      final disponibles = Sqflite.firstIntValue(await txn.rawQuery(
            'SELECT ejemplares_disponibles FROM libros WHERE id = ?',
            [libroId],
          )) ??
          0;

      if (disponibles <= 0) {
        throw SinEjemplaresDisponibles(
          'No hay ejemplares disponibles de este libro.',
        );
      }

      final prestamo = Prestamo(
        libroId: libroId,
        estudianteId: estudianteId,
        fechaPrestamo: inicio,
        fechaDevolucionMax: inicio.add(Duration(days: diasPlazo)),
      );

      final id = await txn.insert(_tabla, prestamo.toMap());

      await txn.rawUpdate(
        'UPDATE libros SET ejemplares_disponibles = ejemplares_disponibles - 1 '
        'WHERE id = ?',
        [libroId],
      );

      return id;
    });
  }

  // ---------------------------------------------------------------- UPDATE
  /// Marca el préstamo como devuelto y repone el ejemplar (RF04).
  Future<void> registrarDevolucion(int prestamoId, {DateTime? fecha}) async {
    final db = await _bd;
    final hoy = fecha ?? DateTime.now();

    await db.transaction((txn) async {
      final filas = await txn.query(
        _tabla,
        where: 'id = ?',
        whereArgs: [prestamoId],
        limit: 1,
      );
      if (filas.isEmpty) {
        throw PrestamoNoEncontrado('El préstamo #$prestamoId no existe.');
      }

      final prestamo = Prestamo.fromMap(filas.first);
      if (!prestamo.estaActivo) {
        throw DevolucionInvalida('Este préstamo ya fue devuelto.');
      }

      await txn.update(
        _tabla,
        {
          'estado': EstadoPrestamo.devuelto,
          'fecha_devolucion_real': Prestamo.formatoIso(hoy),
        },
        where: 'id = ?',
        whereArgs: [prestamoId],
      );

      await txn.rawUpdate(
        'UPDATE libros SET ejemplares_disponibles = '
        'MIN(ejemplares_disponibles + 1, ejemplares_total) WHERE id = ?',
        [prestamo.libroId],
      );
    });
  }

  /// Amplía la fecha máxima de devolución de un préstamo activo.
  Future<int> ampliarPlazo(int prestamoId, int diasAdicionales) async {
    final db = await _bd;
    return db.rawUpdate(
      "UPDATE $_tabla SET fecha_devolucion_max = "
      "date(fecha_devolucion_max, '+$diasAdicionales day') "
      "WHERE id = ? AND estado = ?",
      [prestamoId, EstadoPrestamo.activo],
    );
  }

  // ------------------------------------------------------------------ READ
  Future<List<PrestamoDetalle>> listarActivos() async {
    final db = await _bd;
    final filas = await db.rawQuery(
      '$_consultaDetalle WHERE p.estado = ? ORDER BY p.fecha_devolucion_max ASC',
      [EstadoPrestamo.activo],
    );
    return filas.map(PrestamoDetalle.fromMap).toList();
  }

  /// Últimos préstamos de todos los estudiantes, activos y devueltos.
  Future<List<PrestamoDetalle>> listarHistorial({int limite = 100}) async {
    final db = await _bd;
    final filas = await db.rawQuery(
      '$_consultaDetalle ORDER BY p.fecha_prestamo DESC, p.id DESC LIMIT ?',
      [limite],
    );
    return filas.map(PrestamoDetalle.fromMap).toList();
  }

  Future<int> contarActivos() async {
    final db = await _bd;
    final r = await db.rawQuery(
      'SELECT COUNT(*) FROM $_tabla WHERE estado = ?',
      [EstadoPrestamo.activo],
    );
    return Sqflite.firstIntValue(r) ?? 0;
  }

  /// Préstamos activos cuya fecha máxima ya pasó (hora local del teléfono).
  Future<int> contarVencidos() async {
    final db = await _bd;
    final r = await db.rawQuery(
      "SELECT COUNT(*) FROM $_tabla WHERE estado = ? "
      "AND date(fecha_devolucion_max) < date('now', 'localtime')",
      [EstadoPrestamo.activo],
    );
    return Sqflite.firstIntValue(r) ?? 0;
  }

  /// Historial completo por estudiante (RF05).
  Future<List<PrestamoDetalle>> historialPorEstudiante(int estudianteId) async {
    final db = await _bd;
    final filas = await db.rawQuery(
      '$_consultaDetalle WHERE p.estudiante_id = ? ORDER BY p.fecha_prestamo DESC',
      [estudianteId],
    );
    return filas.map(PrestamoDetalle.fromMap).toList();
  }

  /// Historial completo por libro (RF05).
  Future<List<PrestamoDetalle>> historialPorLibro(int libroId) async {
    final db = await _bd;
    final filas = await db.rawQuery(
      '$_consultaDetalle WHERE p.libro_id = ? ORDER BY p.fecha_prestamo DESC',
      [libroId],
    );
    return filas.map(PrestamoDetalle.fromMap).toList();
  }

  /// Préstamos vencidos o por vencer dentro de [diasAviso] (RF06).
  Future<List<PrestamoDetalle>> porVencer({int diasAviso = 2}) async {
    final db = await _bd;
    final filas = await db.rawQuery(
      "$_consultaDetalle WHERE p.estado = ? "
      "AND date(p.fecha_devolucion_max) <= date('now', 'localtime', '+$diasAviso day') "
      "ORDER BY p.fecha_devolucion_max ASC",
      [EstadoPrestamo.activo],
    );
    return filas.map(PrestamoDetalle.fromMap).toList();
  }

  // ---------------------------------------------------------------- DELETE
  /// Borra un registro del historial. Solo se permite si ya fue devuelto.
  Future<int> eliminar(int prestamoId) async {
    final db = await _bd;
    final filas = await db.query(
      _tabla,
      where: 'id = ?',
      whereArgs: [prestamoId],
      limit: 1,
    );
    if (filas.isEmpty) return 0;

    if (Prestamo.fromMap(filas.first).estaActivo) {
      throw EliminacionNoPermitida(
        'Primero registre la devolución del préstamo.',
      );
    }
    return db.delete(_tabla, where: 'id = ?', whereArgs: [prestamoId]);
  }
}

class SinEjemplaresDisponibles implements Exception {
  final String mensaje;
  SinEjemplaresDisponibles(this.mensaje);
  @override
  String toString() => mensaje;
}

class PrestamoNoEncontrado implements Exception {
  final String mensaje;
  PrestamoNoEncontrado(this.mensaje);
  @override
  String toString() => mensaje;
}

class DevolucionInvalida implements Exception {
  final String mensaje;
  DevolucionInvalida(this.mensaje);
  @override
  String toString() => mensaje;
}
