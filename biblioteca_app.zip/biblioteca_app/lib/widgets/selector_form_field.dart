import 'package:flutter/material.dart';

/// Campo de formulario que abre una hoja inferior con buscador para elegir
/// un elemento de una lista (un libro, un estudiante...).
///
/// Es un [FormField], así que participa de la validación del [Form] igual que
/// un `TextFormField`. Se usa en lugar de un menú desplegable porque el
/// catálogo y la lista de estudiantes pueden ser largos y necesitan búsqueda.
class SelectorFormField<T> extends FormField<T> {
  SelectorFormField({
    super.key,
    required List<T> opciones,
    required String Function(T) titulo,
    String Function(T)? subtitulo,
    required String etiqueta,
    String? ayuda,
    IconData? icono,
    T? valorInicial,
    required ValueChanged<T> alSeleccionar,
    super.validator,
    String textoVacio = 'No hay opciones disponibles',
  }) : super(
          initialValue: valorInicial,
          builder: (FormFieldState<T> estado) {
            final seleccionado = estado.value;
            return Semantics(
              button: true,
              label: etiqueta,
              child: InkWell(
                borderRadius: BorderRadius.circular(4),
                onTap: () async {
                  final elegido = await _abrirSelector<T>(
                    estado.context,
                    titulo: etiqueta,
                    opciones: opciones,
                    tituloDe: titulo,
                    subtituloDe: subtitulo,
                    textoVacio: textoVacio,
                  );
                  if (elegido != null) {
                    estado.didChange(elegido);
                    alSeleccionar(elegido);
                  }
                },
                child: InputDecorator(
                  isEmpty: seleccionado == null,
                  decoration: InputDecoration(
                    labelText: etiqueta,
                    helperText: ayuda,
                    errorText: estado.errorText,
                    prefixIcon: icono == null ? null : Icon(icono),
                    suffixIcon: const Icon(Icons.arrow_drop_down),
                    border: const OutlineInputBorder(),
                  ),
                  child: seleccionado == null
                      ? const SizedBox.shrink()
                      : Text(
                          titulo(seleccionado),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                ),
              ),
            );
          },
        );
}

Future<T?> _abrirSelector<T>(
  BuildContext context, {
  required String titulo,
  required List<T> opciones,
  required String Function(T) tituloDe,
  String Function(T)? subtituloDe,
  required String textoVacio,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (ctx) => _HojaSelector<T>(
      titulo: titulo,
      opciones: opciones,
      tituloDe: tituloDe,
      subtituloDe: subtituloDe,
      textoVacio: textoVacio,
    ),
  );
}

class _HojaSelector<T> extends StatefulWidget {
  final String titulo;
  final List<T> opciones;
  final String Function(T) tituloDe;
  final String Function(T)? subtituloDe;
  final String textoVacio;

  const _HojaSelector({
    required this.titulo,
    required this.opciones,
    required this.tituloDe,
    required this.subtituloDe,
    required this.textoVacio,
  });

  @override
  State<_HojaSelector<T>> createState() => _HojaSelectorState<T>();
}

class _HojaSelectorState<T> extends State<_HojaSelector<T>> {
  String _texto = '';

  List<T> get _filtradas {
    final q = _texto.trim().toLowerCase();
    if (q.isEmpty) return widget.opciones;
    return widget.opciones.where((o) {
      final t = widget.tituloDe(o).toLowerCase();
      final s = (widget.subtituloDe?.call(o) ?? '').toLowerCase();
      return t.contains(q) || s.contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final alto = MediaQuery.sizeOf(context).height * 0.75;
    final filtradas = _filtradas;

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: alto),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(widget.titulo, style: tema.textTheme.titleMedium),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                autofocus: false,
                decoration: const InputDecoration(
                  hintText: 'Buscar',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) => setState(() => _texto = v),
              ),
            ),
            const SizedBox(height: 8),
            Flexible(
              child: filtradas.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.all(32),
                      child: Center(child: Text(widget.textoVacio)),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: filtradas.length,
                      itemBuilder: (ctx, i) {
                        final opcion = filtradas[i];
                        final sub = widget.subtituloDe?.call(opcion);
                        return ListTile(
                          title: Text(widget.tituloDe(opcion)),
                          subtitle: sub == null ? null : Text(sub),
                          onTap: () => Navigator.pop(ctx, opcion),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
