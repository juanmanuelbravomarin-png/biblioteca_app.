import 'package:flutter/material.dart';

/// Tarjeta con una cifra destacada (por ejemplo, "12 · Préstamos activos").
/// Si recibe [alTocar] funciona como un acceso directo a otra sección.
class TarjetaResumen extends StatelessWidget {
  final IconData icono;
  final String valor;
  final String etiqueta;
  final Color? color;
  final VoidCallback? alTocar;

  const TarjetaResumen({
    super.key,
    required this.icono,
    required this.valor,
    required this.etiqueta,
    this.color,
    this.alTocar,
  });

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final c = color ?? tema.colorScheme.primary;
    return MergeSemantics(
      child: Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: alTocar,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icono, color: c),
                const SizedBox(height: 12),
                Text(
                  valor,
                  style: tema.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: c,
                  ),
                ),
                Text(etiqueta, style: tema.textTheme.bodyMedium),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
