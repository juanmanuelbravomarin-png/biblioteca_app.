import 'package:flutter/material.dart';

import '../models/prestamo.dart';
import '../utils/formato.dart';
import 'estado_chip.dart';

/// Tarjeta de un préstamo: libro, estudiante, fechas y estado.
/// Los botones de acción solo aparecen si se pasan los callbacks.
class PrestamoCard extends StatelessWidget {
  final PrestamoDetalle detalle;
  final VoidCallback? alDevolver;
  final VoidCallback? alAmpliar;

  const PrestamoCard({
    super.key,
    required this.detalle,
    this.alDevolver,
    this.alAmpliar,
  });

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final p = detalle.prestamo;
    final grado =
        detalle.gradoEstudiante.isEmpty ? 'sin grado' : detalle.gradoEstudiante;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    detalle.tituloLibro,
                    style: tema.textTheme.titleMedium,
                  ),
                ),
                const SizedBox(width: 8),
                Flexible(child: EstadoChip.dePrestamo(p)),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${detalle.nombreEstudiante} · $grado',
              style: tema.textTheme.bodyMedium,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 16,
              runSpacing: 4,
              children: [
                _dato(context, Icons.event, 'Prestado',
                    Formato.fecha(p.fechaPrestamo)),
                _dato(context, Icons.event_busy_outlined, 'Máximo',
                    Formato.fecha(p.fechaDevolucionMax)),
                if (p.fechaDevolucionReal != null)
                  _dato(context, Icons.assignment_turned_in_outlined,
                      'Devuelto', Formato.fecha(p.fechaDevolucionReal!)),
              ],
            ),
            if (alDevolver != null || alAmpliar != null) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (alDevolver != null)
                    FilledButton.icon(
                      onPressed: alDevolver,
                      icon: const Icon(Icons.assignment_return_outlined),
                      label: const Text('Registrar devolución'),
                    ),
                  if (alAmpliar != null)
                    OutlinedButton.icon(
                      onPressed: alAmpliar,
                      icon: const Icon(Icons.more_time),
                      label: const Text('+3 días'),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _dato(BuildContext context, IconData icono, String etiqueta,
      String valor) {
    final tema = Theme.of(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icono, size: 16, color: tema.colorScheme.onSurfaceVariant),
        const SizedBox(width: 4),
        Text('$etiqueta: $valor', style: tema.textTheme.bodySmall),
      ],
    );
  }
}
