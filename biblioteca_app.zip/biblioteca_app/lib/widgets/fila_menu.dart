import 'package:flutter/material.dart';

/// Contenido de una opción de menú desplegable: icono + texto.
class FilaMenu extends StatelessWidget {
  final IconData icono;
  final String texto;

  const FilaMenu(this.icono, this.texto, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [Icon(icono, size: 20), const SizedBox(width: 12), Text(texto)],
    );
  }
}
