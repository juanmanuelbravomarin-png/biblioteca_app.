import 'package:flutter/material.dart';

import '../data/estudiante_dao.dart';
import '../data/libro_dao.dart';
import '../data/prestamo_dao.dart';
import '../models/estudiante.dart';
import '../models/libro.dart';
import '../state/app_state.dart';
import '../utils/formato.dart';
import '../utils/mensajes.dart';
import '../widgets/contenido_centrado.dart';
import '../widgets/estado_vacio.dart';
import '../widgets/selector_form_field.dart';

/// Registro de un préstamo (RF03): elegir libro, estudiante y fecha máxima
/// de devolución. Puede abrirse con el libro o el estudiante ya elegidos.
class PrestamoFormScreen extends StatefulWidget {
  final Libro? libroInicial;
  final Estudiante? estudianteInicial;

  const PrestamoFormScreen({
    super.key,
    this.libroInicial,
    this.estudianteInicial,
  });

  @override
  State<PrestamoFormScreen> createState() => _PrestamoFormScreenState();
}

class _PrestamoFormScreenState extends State<PrestamoFormScreen> {
  static const _plazosRapidos = [3, 8, 15];
  static const _plazoMaximo = 30;

  final _formKey = GlobalKey<FormState>();
  final _controladorFecha = TextEditingController();

  List<Libro> _libros = [];
  List<Estudiante> _estudiantes = [];
  Libro? _libro;
  Estudiante? _estudiante;
  DateTime? _fechaLimite;

  bool _cargando = true;
  bool _errorCarga = false;
  bool _guardando = false;

  @override
  void initState() {
    super.initState();
    _libro = widget.libroInicial;
    _estudiante = widget.estudianteInicial;
    _fijarPlazo(8);
    _cargarOpciones();
  }

  @override
  void dispose() {
    _controladorFecha.dispose();
    super.dispose();
  }

  Future<void> _cargarOpciones() async {
    try {
      final libros =
          await LibroDao().listar(filtro: FiltroDisponibilidad.disponibles);
      final estudiantes = await EstudianteDao().listar();
      if (!mounted) return;
      setState(() {
        _libros = libros;
        _estudiantes = estudiantes;
        // Si el libro inicial ya no está disponible, se descarta.
        if (_libro != null && !libros.any((l) => l.id == _libro!.id)) {
          _libro = null;
        }
        _cargando = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _cargando = false;
        _errorCarga = true;
      });
    }
  }

  /// Fija la fecha máxima a [dias] días a partir de hoy.
  void _fijarPlazo(int dias) {
    final fecha = Formato.soloFecha(DateTime.now().add(Duration(days: dias)));
    _fechaLimite = fecha;
    _controladorFecha.text = Formato.fecha(fecha);
  }

  Future<void> _elegirFecha() async {
    final hoy = Formato.soloFecha(DateTime.now());
    final elegida = await showDatePicker(
      context: context,
      initialDate: _fechaLimite ?? hoy.add(const Duration(days: 8)),
      firstDate: hoy.add(const Duration(days: 1)),
      lastDate: hoy.add(const Duration(days: _plazoMaximo)),
      helpText: 'Fecha máxima de devolución',
    );
    if (elegida == null) return;
    setState(() {
      _fechaLimite = elegida;
      _controladorFecha.text = Formato.fecha(elegida);
    });
  }

  String? _validarFecha(String? _) {
    final fecha = _fechaLimite;
    if (fecha == null) return 'Elija la fecha máxima de devolución';
    final hoy = Formato.soloFecha(DateTime.now());
    if (!fecha.isAfter(hoy)) return 'La fecha debe ser posterior a hoy';
    if (fecha.difference(hoy).inDays > _plazoMaximo) {
      return 'El plazo máximo es de $_plazoMaximo días';
    }
    return null;
  }

  Future<void> _guardar() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _guardando = true);

    final dias = Formato.soloFecha(_fechaLimite!)
        .difference(Formato.soloFecha(DateTime.now()))
        .inDays;

    try {
      await PrestamoDao().registrarPrestamo(
        libroId: _libro!.id!,
        estudianteId: _estudiante!.id!,
        diasPlazo: dias,
      );
      AppState.instancia.datosCambiaron();
      if (!mounted) return;
      mostrarMensaje(
        context,
        'Préstamo registrado: "${_libro!.titulo}" para ${_estudiante!.nombre}.',
      );
      Navigator.pop(context, true);
    } on SinEjemplaresDisponibles catch (e) {
      if (!mounted) return;
      setState(() => _guardando = false);
      mostrarMensaje(context, e.mensaje, error: true);
      _cargarOpciones();
    } catch (_) {
      if (!mounted) return;
      setState(() => _guardando = false);
      mostrarMensaje(context, 'No se pudo registrar el préstamo.', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nuevo préstamo')),
      body: _cuerpo(),
    );
  }

  Widget _cuerpo() {
    if (_cargando) return const Center(child: CircularProgressIndicator());

    if (_errorCarga) {
      return const EstadoVacio(
        icono: Icons.error_outline,
        titulo: 'No se pudieron cargar los datos',
        mensaje: 'Cierre esta pantalla e intente de nuevo.',
      );
    }

    if (_estudiantes.isEmpty) {
      return const EstadoVacio(
        icono: Icons.people_outline,
        titulo: 'Aún no hay estudiantes',
        mensaje: 'Registre al menos un estudiante para poder prestar libros.',
      );
    }

    if (_libros.isEmpty) {
      return const EstadoVacio(
        icono: Icons.menu_book_outlined,
        titulo: 'No hay libros disponibles',
        mensaje:
            'Todos los ejemplares están prestados o el catálogo está vacío.',
      );
    }

    final tema = Theme.of(context);
    return ContenidoCentrado(
      child: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SelectorFormField<Libro>(
              etiqueta: 'Libro',
              icono: Icons.menu_book_outlined,
              opciones: _libros,
              valorInicial: _libro,
              titulo: (l) => l.titulo,
              subtitulo: (l) =>
                  '${l.autor} · ${l.codigo} · ${l.ejemplaresDisponibles} disponible(s)',
              alSeleccionar: (l) => setState(() => _libro = l),
              validator: (l) => l == null ? 'Elija el libro' : null,
            ),
            const SizedBox(height: 16),
            SelectorFormField<Estudiante>(
              etiqueta: 'Estudiante',
              icono: Icons.person_outline,
              opciones: _estudiantes,
              valorInicial: _estudiante,
              titulo: (e) => e.nombre,
              subtitulo: (e) =>
                  'Documento ${e.documento}${e.grado.isEmpty ? '' : ' · Grado ${e.grado}'}',
              alSeleccionar: (e) => setState(() => _estudiante = e),
              validator: (e) => e == null ? 'Elija el estudiante' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _controladorFecha,
              readOnly: true,
              onTap: _elegirFecha,
              decoration: const InputDecoration(
                labelText: 'Fecha máxima de devolución',
                prefixIcon: Icon(Icons.event),
                suffixIcon: Icon(Icons.calendar_month_outlined),
                border: OutlineInputBorder(),
              ),
              validator: _validarFecha,
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text('Plazo rápido:', style: tema.textTheme.bodySmall),
                for (final d in _plazosRapidos)
                  ActionChip(
                    label: Text('$d días'),
                    onPressed: () => setState(() => _fijarPlazo(d)),
                  ),
              ],
            ),
            const SizedBox(height: 32),
            FilledButton.icon(
              onPressed: _guardando ? null : _guardar,
              icon: const Icon(Icons.check),
              label: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(_guardando ? 'Registrando…' : 'Registrar préstamo'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
