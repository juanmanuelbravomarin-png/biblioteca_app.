import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/estudiante_dao.dart';
import '../models/estudiante.dart';
import '../state/app_state.dart';
import '../utils/mensajes.dart';
import '../utils/validadores.dart';
import '../widgets/contenido_centrado.dart';

/// Alta y edición de un estudiante.
/// Si [estudiante] es null, el formulario crea un registro nuevo.
class EstudianteFormScreen extends StatefulWidget {
  final Estudiante? estudiante;
  const EstudianteFormScreen({super.key, this.estudiante});

  @override
  State<EstudianteFormScreen> createState() => _EstudianteFormScreenState();
}

class _EstudianteFormScreenState extends State<EstudianteFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dao = EstudianteDao();

  late final TextEditingController _documento;
  late final TextEditingController _nombre;
  late final TextEditingController _grado;

  bool _guardando = false;

  bool get _esEdicion => widget.estudiante != null;

  @override
  void initState() {
    super.initState();
    final e = widget.estudiante;
    _documento = TextEditingController(text: e?.documento ?? '');
    _nombre = TextEditingController(text: e?.nombre ?? '');
    _grado = TextEditingController(text: e?.grado ?? '');
  }

  @override
  void dispose() {
    _documento.dispose();
    _nombre.dispose();
    _grado.dispose();
    super.dispose();
  }

  Future<void> _guardar() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _guardando = true);

    final estudiante = Estudiante(
      id: widget.estudiante?.id,
      documento: _documento.text.trim(),
      nombre: _nombre.text.trim(),
      grado: Validadores.normalizarGrado(_grado.text),
    );

    try {
      if (_esEdicion) {
        await _dao.actualizar(estudiante);
      } else {
        await _dao.insertar(estudiante);
      }
      AppState.instancia.datosCambiaron();
      if (!mounted) return;
      mostrarMensaje(
        context,
        _esEdicion ? 'Estudiante actualizado' : 'Estudiante guardado',
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _guardando = false);
      mostrarMensaje(
        context,
        esErrorUnico(e)
            ? 'Ya existe un estudiante con el documento ${estudiante.documento}.'
            : 'No se pudo guardar el estudiante. Intente de nuevo.',
        error: true,
      );
    }
  }

  InputDecoration _decoracion(String etiqueta, {String? ayuda, IconData? icono}) {
    return InputDecoration(
      labelText: etiqueta,
      helperText: ayuda,
      prefixIcon: icono == null ? null : Icon(icono),
      border: const OutlineInputBorder(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_esEdicion ? 'Editar estudiante' : 'Nuevo estudiante'),
      ),
      body: ContenidoCentrado(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextFormField(
                controller: _documento,
                keyboardType: TextInputType.number,
                textInputAction: TextInputAction.next,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: _decoracion(
                  'Documento de identidad',
                  ayuda: 'Solo números, entre 5 y 12 dígitos',
                  icono: Icons.badge_outlined,
                ),
                validator: Validadores.documento,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nombre,
                textCapitalization: TextCapitalization.words,
                textInputAction: TextInputAction.next,
                decoration: _decoracion(
                  'Nombre completo',
                  icono: Icons.person_outline,
                ),
                validator: Validadores.nombrePersona,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _grado,
                textCapitalization: TextCapitalization.characters,
                textInputAction: TextInputAction.done,
                decoration: _decoracion(
                  'Grado y grupo',
                  ayuda: 'Ej. 2-A',
                  icono: Icons.school_outlined,
                ),
                validator: Validadores.grado,
                onFieldSubmitted: (_) => _guardando ? null : _guardar(),
              ),
              const SizedBox(height: 32),
              FilledButton(
                onPressed: _guardando ? null : _guardar,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(_guardando ? 'Guardando…' : 'Guardar estudiante'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
