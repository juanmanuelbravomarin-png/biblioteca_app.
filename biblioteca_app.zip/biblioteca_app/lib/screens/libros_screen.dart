import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../data/libro_dao.dart';
import '../data/prestamo_dao.dart';
import '../models/libro.dart';
import '../state/app_state.dart';
import '../utils/mensajes.dart';
import '../widgets/contenido_centrado.dart';
import '../widgets/estado_chip.dart';
import '../widgets/estado_vacio.dart';
import '../widgets/fila_menu.dart';
import 'historial_screen.dart';
import 'libro_form_screen.dart';
import 'prestamo_form_screen.dart';

enum _AccionLibro { editar, prestar, historial, eliminar }

/// Catálogo: listar, buscar y filtrar (RF02) y crear/editar/eliminar (RF07).
class LibrosScreen extends StatefulWidget {
  const LibrosScreen({super.key});

  @override
  State<LibrosScreen> createState() => _LibrosScreenState();
}

class _LibrosScreenState extends State<LibrosScreen> {
  final _dao = LibroDao();
  final _busqueda = TextEditingController();
  Timer? _espera;

  List<Libro> _libros = [];
  FiltroDisponibilidad _filtro = FiltroDisponibilidad.todos;
  bool _cargando = true;
  bool _error = false;
  int _consulta = 0;

  @override
  void initState() {
    super.initState();
    AppState.instancia.addListener(_cargar);
    _cargar();
  }

  @override
  void dispose() {
    AppState.instancia.removeListener(_cargar);
    _espera?.cancel();
    _busqueda.dispose();
    super.dispose();
  }

  Future<void> _cargar() async {
    // Si llegan varias consultas seguidas solo se muestra la última.
    final id = ++_consulta;
    try {
      final datos = await _dao.listar(busqueda: _busqueda.text, filtro: _filtro);
      if (!mounted || id != _consulta) return;
      setState(() {
        _libros = datos;
        _cargando = false;
        _error = false;
      });
    } catch (_) {
      if (!mounted || id != _consulta) return;
      setState(() {
        _cargando = false;
        _error = true;
      });
    }
  }

  /// Espera a que el usuario deje de escribir antes de consultar.
  void _alEscribir(String _) {
    setState(() {}); // actualiza el botón de limpiar
    _espera?.cancel();
    _espera = Timer(const Duration(milliseconds: 300), _cargar);
  }

  void _abrir(Widget pantalla) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => pantalla));
  }

  Future<void> _eliminar(Libro libro) async {
    final acepta = await confirmar(
      context,
      titulo: 'Eliminar libro',
      mensaje: '¿Eliminar "${libro.titulo}" del catálogo?',
      textoConfirmar: 'Eliminar',
    );
    if (!acepta || !mounted) return;

    try {
      await _dao.eliminar(libro.id!);
      AppState.instancia.datosCambiaron();
      if (mounted) mostrarMensaje(context, 'Libro eliminado');
    } on EliminacionNoPermitida catch (e) {
      if (mounted) mostrarMensaje(context, e.mensaje, error: true);
    } catch (_) {
      if (mounted) mostrarMensaje(
          context,
          'No se puede eliminar: el libro tiene préstamos en su historial.',
          error: true,
        );
    }
  }

  void _alElegirAccion(_AccionLibro accion, Libro libro) {
    switch (accion) {
      case _AccionLibro.editar:
        _abrir(LibroFormScreen(libro: libro));
      case _AccionLibro.prestar:
        _abrir(PrestamoFormScreen(libroInicial: libro));
      case _AccionLibro.historial:
        _abrir(HistorialScreen(
          titulo: 'Historial del libro',
          subtitulo: libro.titulo,
          cargar: () => PrestamoDao().historialPorLibro(libro.id!),
        ));
      case _AccionLibro.eliminar:
        _eliminar(libro);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Catálogo de libros')),
      floatingActionButton: FloatingActionButton.extended(
        // Sin héroe: las tres pestañas viven a la vez en un IndexedStack y
        // compartirían la misma etiqueta de animación al navegar.
        heroTag: null,
        onPressed: () => _abrir(const LibroFormScreen()),
        icon: const Icon(Icons.add),
        label: const Text('Nuevo libro'),
      ),
      body: ContenidoCentrado(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: TextField(
                controller: _busqueda,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'Buscar por título, autor o código',
                  prefixIcon: const Icon(Icons.search),
                  border: const OutlineInputBorder(),
                  suffixIcon: _busqueda.text.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close),
                          tooltip: 'Limpiar búsqueda',
                          onPressed: () {
                            _busqueda.clear();
                            setState(() {});
                            _cargar();
                          },
                        ),
                ),
                onChanged: _alEscribir,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Wrap(
                  spacing: 8,
                  children: [
                    for (final opcion in FiltroDisponibilidad.values)
                      ChoiceChip(
                        label: Text(_etiquetaFiltro(opcion)),
                        selected: _filtro == opcion,
                        onSelected: (_) {
                          setState(() => _filtro = opcion);
                          _cargar();
                        },
                      ),
                  ],
                ),
              ),
            ),
            Expanded(child: _lista()),
          ],
        ),
      ),
    );
  }

  String _etiquetaFiltro(FiltroDisponibilidad f) => switch (f) {
        FiltroDisponibilidad.todos => 'Todos',
        FiltroDisponibilidad.disponibles => 'Disponibles',
        FiltroDisponibilidad.prestados => 'Prestados',
      };

  Widget _lista() {
    if (_cargando) return const Center(child: CircularProgressIndicator());

    if (_error) {
      return EstadoVacio(
        icono: Icons.error_outline,
        titulo: 'No se pudo cargar el catálogo',
        mensaje: 'Intente de nuevo.',
        accion: FilledButton(onPressed: _cargar, child: const Text('Reintentar')),
      );
    }

    if (_libros.isEmpty) {
      return ListView(
        children: const [
          SizedBox(height: 48),
          EstadoVacio(
            icono: Icons.menu_book_outlined,
            titulo: 'No hay libros que mostrar',
            mensaje:
                'Cambie la búsqueda o el filtro, o agregue un título con el botón "Nuevo libro".',
          ),
        ],
      );
    }

    return RefreshIndicator(
      onRefresh: _cargar,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 96),
        itemCount: _libros.length,
        itemBuilder: (context, i) => _tarjeta(_libros[i]),
      ),
    );
  }

  Widget _tarjeta(Libro libro) {
    final tema = Theme.of(context);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _abrir(LibroFormScreen(libro: libro)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 4, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _miniatura(libro),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      libro.titulo,
                      style: tema.textTheme.titleMedium,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${libro.autor} · ${libro.codigo}',
                      style: tema.textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        EstadoChip.deLibro(libro),
                        Text(
                          '${libro.ejemplaresDisponibles} de ${libro.ejemplaresTotal} ejemplares',
                          style: tema.textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              PopupMenuButton<_AccionLibro>(
                tooltip: 'Más acciones',
                onSelected: (a) => _alElegirAccion(a, libro),
                itemBuilder: (_) => [
                  _item(_AccionLibro.editar, Icons.edit_outlined, 'Editar'),
                  PopupMenuItem(
                    value: _AccionLibro.prestar,
                    enabled: libro.disponible,
                    child: const FilaMenu(Icons.swap_horiz, 'Prestar'),
                  ),
                  _item(_AccionLibro.historial, Icons.history, 'Historial'),
                  _item(_AccionLibro.eliminar, Icons.delete_outline, 'Eliminar'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  PopupMenuItem<_AccionLibro> _item(
      _AccionLibro valor, IconData icono, String texto) {
    return PopupMenuItem(value: valor, child: FilaMenu(icono, texto));
  }

  Widget _miniatura(Libro libro) {
    final ruta = libro.portadaPath;
    if (ruta != null && File(ruta).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Image.file(File(ruta), width: 52, height: 72, fit: BoxFit.cover),
      );
    }
    final esquema = Theme.of(context).colorScheme;
    return Container(
      width: 52,
      height: 72,
      decoration: BoxDecoration(
        color: esquema.primaryContainer,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Icon(Icons.menu_book_outlined, color: esquema.onPrimaryContainer),
    );
  }
}

