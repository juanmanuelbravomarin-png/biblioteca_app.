import 'package:flutter/material.dart';

import 'estudiantes_screen.dart';
import 'inicio_screen.dart';
import 'libros_screen.dart';
import 'prestamos_screen.dart';

/// Pantalla contenedora: muestra el menú de navegación y la sección activa.
///
/// * En teléfono (ancho < 800) el menú es una barra inferior.
/// * En tableta o ventana ancha pasa a ser un riel lateral.
///
/// Las cuatro secciones se mantienen vivas con [IndexedStack], de modo que al
/// cambiar de pestaña no se pierde el texto de búsqueda ni la posición de la
/// lista.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _Destino {
  final String etiqueta;
  final IconData icono;
  final IconData iconoActivo;
  const _Destino(this.etiqueta, this.icono, this.iconoActivo);
}

class _HomeShellState extends State<HomeShell> {
  static const _destinos = [
    _Destino('Inicio', Icons.home_outlined, Icons.home),
    _Destino('Libros', Icons.menu_book_outlined, Icons.menu_book),
    _Destino('Préstamos', Icons.swap_horiz_outlined, Icons.swap_horiz),
    _Destino('Estudiantes', Icons.people_outline, Icons.people),
  ];

  int _indice = 0;

  void _ir(int i) => setState(() => _indice = i);

  @override
  Widget build(BuildContext context) {
    final cuerpo = IndexedStack(
      index: _indice,
      children: [
        InicioScreen(alIrA: _ir),
        const LibrosScreen(),
        const PrestamosScreen(),
        const EstudiantesScreen(),
      ],
    );

    final ancha = MediaQuery.sizeOf(context).width >= 800;

    // El botón "atrás" del teléfono vuelve primero a Inicio y, estando en
    // Inicio, cierra la app.
    return PopScope(
      canPop: _indice == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _ir(0);
      },
      child: ancha
          ? Scaffold(
              body: Row(
                children: [
                  NavigationRail(
                    selectedIndex: _indice,
                    onDestinationSelected: _ir,
                    labelType: NavigationRailLabelType.all,
                    destinations: [
                      for (final d in _destinos)
                        NavigationRailDestination(
                          icon: Icon(d.icono),
                          selectedIcon: Icon(d.iconoActivo),
                          label: Text(d.etiqueta),
                        ),
                    ],
                  ),
                  const VerticalDivider(width: 1),
                  Expanded(child: cuerpo),
                ],
              ),
            )
          : Scaffold(
              body: cuerpo,
              bottomNavigationBar: NavigationBar(
                selectedIndex: _indice,
                onDestinationSelected: _ir,
                destinations: [
                  for (final d in _destinos)
                    NavigationDestination(
                      icon: Icon(d.icono),
                      selectedIcon: Icon(d.iconoActivo),
                      label: d.etiqueta,
                    ),
                ],
              ),
            ),
    );
  }
}
