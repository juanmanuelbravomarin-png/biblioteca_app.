import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/libro_dao.dart';
import '../models/libro.dart';
import '../state/app_state.dart';
import '../utils/mensajes.dart';
import '../utils/validadores.dart';
import '../widgets/contenido_centrado.dart';

/// Alta y edición de un libro (CREATE / UPDATE del RF07).
/// Si [libro] es null, el formulario crea un registro nuevo.
class LibroFormScreen extends StatefulWidget {
  final Libro? libro;
  const LibroFormScreen({super.key, this.libro});

  @override
  State<LibroFormScreen> createState() => _LibroFormScreenState();
}

class _LibroFormScreenState extends State<LibroFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dao = LibroDao();

  late final TextEditingController _codigo;
  late final TextEditingController _titulo;
  late final TextEditingController _autor;
  late final TextEditingController _categoria;
  late final TextEditingController _ejemplares;

  String? _portadaPath;
  bool _guardando = false;

  bool get _esEdicion => widget.libro != null;

  /// Ejemplares que están fuera de la biblioteca (prestados) al editar.
  int get _prestados => _esEdicion
      ? widget.libro!.ejemplaresTotal - widget.libro!.ejemplaresDisponibles
      : 0;

  @override
  void initState() {
    super.initState();
    final l = widget.libro;
    _codigo = TextEditingController(text: l?.codigo ?? '');
    _titulo = TextEditingController(text: l?.titulo ?? '');
    _autor = TextEditingController(text: l?.autor ?? '');
    _categoria = TextEditingController(text: l?.categoria ?? 'General');
    _ejemplares =
        TextEditingController(text: (l?.ejemplaresTotal ?? 1).toString());
    _portadaPath = l?.portadaPath;
  }

  @override
  void dispose() {
    _codigo.dispose();
    _titulo.dispose();
    _autor.dispose();
    _categoria.dispose();
    _ejemplares.dispose();
    super.dispose();
  }

  /// Servicio del dispositivo: cámara para la portada del ejemplar.
  Future<void> _tomarFoto() async {
    try {
      final archivo = await ImagePicker().pickImage(
        source: ImageSource.camera,
        maxWidth: 800,
        imageQuality: 70,
      );
      if (archivo != null && mounted) {
        setState(() => _portadaPath = archivo.path);
      }
    } catch (_) {
      if (mounted) {
        mostrarMensaje(context, 'No se pudo abrir la cámara.', error: true);
      }
    }
  }

  String? _validarEjemplares(String? v) {
    final base = Validadores.entero(v, minimo: 1, maximo: 999);
    if (base != null) return base;
    final total = int.parse(v!.trim());
    if (total < _prestados) {
      return 'Hay $_prestados ejemplar(es) prestados; no puede ser menos';
    }
    return null;
  }

  Future<void> _guardar() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _guardando = true);

    final total = int.parse(_ejemplares.text.trim());
    final libro = Libro(
      id: widget.libro?.id,
      codigo: _codigo.text.trim().toUpperCase(),
      titulo: _titulo.text.trim(),
      autor: _autor.text.trim(),
      categoria:
          _categoria.text.trim().isEmpty ? 'General' : _categoria.text.trim(),
      ejemplaresTotal: total,
      // Al editar se conservan los ejemplares que están afuera prestados.
      ejemplaresDisponibles: (total - _prestados).clamp(0, total),
      portadaPath: _portadaPath,
    );

    try {
      if (_esEdicion) {
        await _dao.actualizar(libro);
      } else {
        await _dao.insertar(libro);
      }
      AppState.instancia.datosCambiaron();
      if (!mounted) return;
      // El mensaje se muestra antes de cerrar: el SnackBar pertenece al
      // MaterialApp, así que sigue visible en la pantalla anterior.
      mostrarMensaje(context, _esEdicion ? 'Libro actualizado' : 'Libro guardado');
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _guardando = false);
      mostrarMensaje(
        context,
        esErrorUnico(e)
            ? 'Ya existe un libro con el código ${libro.codigo}.'
            : 'No se pudo guardar el libro. Intente de nuevo.',
        error: true,
      );
    }
  }

  InputDecoration _decoracion(String etiqueta, {String? ayuda, IconData? icono}) {
    return InputDecoration(
      labelText: etiqueta,
      helperText: ayuda,
      prefixIcon: icono == null ? null : Icon(icono),
      border: const OutlineInputBorder(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_esEdicion ? 'Editar libro' : 'Nuevo libro')),
      body: ContenidoCentrado(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextFormField(
                controller: _codigo,
                textCapitalization: TextCapitalization.characters,
                textInputAction: TextInputAction.next,
                decoration: _decoracion(
                  'Código',
                  ayuda: 'Identificador único del libro, ej. LIT-001',
                  icono: Icons.qr_code_2,
                ),
                validator: (v) => Validadores.requerido(v, 'el código'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _titulo,
                textCapitalization: TextCapitalization.sentences,
                textInputAction: TextInputAction.next,
                decoration: _decoracion('Título', icono: Icons.title),
                validator: (v) => Validadores.requerido(v, 'el título'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _autor,
                textCapitalization: TextCapitalization.words,
                textInputAction: TextInputAction.next,
                decoration: _decoracion('Autor', icono: Icons.person_outline),
                validator: (v) => Validadores.requerido(v, 'el autor'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _categoria,
                textCapitalization: TextCapitalization.sentences,
                textInputAction: TextInputAction.next,
                decoration: _decoracion('Categoría',
                    ayuda: 'Opcional. Si la deja vacía será "General"',
                    icono: Icons.category_outlined),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _ejemplares,
                keyboardType: TextInputType.number,
                decoration: _decoracion(
                  'Cantidad de ejemplares',
                  icono: Icons.numbers,
                ),
                validator: _validarEjemplares,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  if (_portadaPath != null && File(_portadaPath!).existsSync())
                    Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(
                          File(_portadaPath!),
                          width: 64,
                          height: 88,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  Flexible(
                    child: OutlinedButton.icon(
                      onPressed: _tomarFoto,
                      icon: const Icon(Icons.photo_camera_outlined),
                      label: Text(
                        _portadaPath == null ? 'Tomar portada' : 'Cambiar portada',
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
              FilledButton(
                onPressed: _guardando ? null : _guardar,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(_guardando ? 'Guardando…' : 'Guardar libro'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
