import 'package:flutter/material.dart';

import '../data/estudiante_dao.dart';
import '../data/libro_dao.dart';
import '../data/prestamo_dao.dart';
import '../models/prestamo.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/contenido_centrado.dart';
import '../widgets/estado_chip.dart';
import '../widgets/estado_vacio.dart';
import '../widgets/tarjeta_resumen.dart';
import 'estudiante_form_screen.dart';
import 'libro_form_screen.dart';
import 'prestamo_form_screen.dart';

/// Pantalla principal: resumen de la biblioteca, accesos rápidos y alertas.
class InicioScreen extends StatefulWidget {
  /// Cambia a otra sección del menú (0 inicio, 1 libros, 2 préstamos,
  /// 3 estudiantes).
  final ValueChanged<int> alIrA;

  const InicioScreen({super.key, required this.alIrA});

  @override
  State<InicioScreen> createState() => _InicioScreenState();
}

class _Resumen {
  final int titulos;
  final int ejemplares;
  final int estudiantes;
  final int activos;
  final int vencidos;
  final List<PrestamoDetalle> alertas;

  const _Resumen({
    required this.titulos,
    required this.ejemplares,
    required this.estudiantes,
    required this.activos,
    required this.vencidos,
    required this.alertas,
  });
}

class _InicioScreenState extends State<InicioScreen> {
  _Resumen? _resumen;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    AppState.instancia.addListener(_cargar);
    _cargar();
  }

  @override
  void dispose() {
    AppState.instancia.removeListener(_cargar);
    super.dispose();
  }

  Future<void> _cargar() async {
    try {
      final libros = LibroDao();
      final prestamos = PrestamoDao();
      final r = await Future.wait<Object>([
        libros.contar(),
        libros.totalEjemplaresDisponibles(),
        EstudianteDao().contar(),
        prestamos.contarActivos(),
        prestamos.contarVencidos(),
        prestamos.porVencer(),
      ]);
      if (!mounted) return;
      setState(() {
        _error = false;
        _resumen = _Resumen(
          titulos: r[0] as int,
          ejemplares: r[1] as int,
          estudiantes: r[2] as int,
          activos: r[3] as int,
          vencidos: r[4] as int,
          alertas: r[5] as List<PrestamoDetalle>,
        );
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = true);
    }
  }

  void _abrir(Widget pantalla) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => pantalla));
  }

  void _acercaDe() {
    showAboutDialog(
      context: context,
      applicationName: 'Biblioteca Sede 2',
      applicationVersion: '1.0.0 · Fase 3',
      applicationIcon: const Icon(Icons.local_library, size: 40),
      applicationLegalese:
          'I.E. Colegio Puerto Santander, Sede 2\n'
          'Curso Framework para el Desarrollo de Aplicaciones Móviles (UNAD)',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Biblioteca Sede 2'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'Acerca de la aplicación',
            onPressed: _acercaDe,
          ),
        ],
      ),
      body: _contenido(),
    );
  }

  Widget _contenido() {
    final resumen = _resumen;
    if (resumen == null) {
      return _error
          ? EstadoVacio(
              icono: Icons.error_outline,
              titulo: 'No se pudo cargar el resumen',
              mensaje: 'Revise el almacenamiento del dispositivo e intente de nuevo.',
              accion: FilledButton(
                onPressed: _cargar,
                child: const Text('Reintentar'),
              ),
            )
          : const Center(child: CircularProgressIndicator());
    }

    final tema = Theme.of(context);
    return RefreshIndicator(
      onRefresh: _cargar,
      child: ContenidoCentrado(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Control de préstamos', style: tema.textTheme.headlineSmall),
            const SizedBox(height: 4),
            Text(
              'Institución Educativa Colegio Puerto Santander · Sede 2',
              style: tema.textTheme.bodyMedium?.copyWith(
                color: tema.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            _tarjetas(resumen),
            const SizedBox(height: 24),
            Text('Acciones rápidas', style: tema.textTheme.titleMedium),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: () => _abrir(const PrestamoFormScreen()),
                  icon: const Icon(Icons.add_circle_outline),
                  label: const Text('Nuevo préstamo'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () => _abrir(const LibroFormScreen()),
                  icon: const Icon(Icons.library_add_outlined),
                  label: const Text('Registrar libro'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () => _abrir(const EstudianteFormScreen()),
                  icon: const Icon(Icons.person_add_alt_1_outlined),
                  label: const Text('Registrar estudiante'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: Text('Requieren atención',
                      style: tema.textTheme.titleMedium),
                ),
                if (resumen.alertas.isNotEmpty)
                  TextButton(
                    onPressed: () => widget.alIrA(2),
                    child: const Text('Ver préstamos'),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            _alertas(resumen),
          ],
        ),
      ),
    );
  }

  /// Cuadrícula de cifras: 2 columnas en teléfono, 4 en pantallas anchas.
  Widget _tarjetas(_Resumen r) {
    final tarjetas = [
      TarjetaResumen(
        icono: Icons.menu_book_outlined,
        valor: '${r.titulos}',
        etiqueta: 'Títulos en catálogo',
        alTocar: () => widget.alIrA(1),
      ),
      TarjetaResumen(
        icono: Icons.inventory_2_outlined,
        valor: '${r.ejemplares}',
        etiqueta: 'Ejemplares disponibles',
        alTocar: () => widget.alIrA(1),
      ),
      TarjetaResumen(
        icono: Icons.swap_horiz,
        valor: '${r.activos}',
        etiqueta: 'Préstamos activos',
        alTocar: () => widget.alIrA(2),
      ),
      TarjetaResumen(
        icono: Icons.warning_amber_rounded,
        valor: '${r.vencidos}',
        etiqueta: 'Préstamos vencidos',
        color: r.vencidos > 0 ? AppTheme.peligro : AppTheme.ok,
        alTocar: () => widget.alIrA(2),
      ),
    ];

    return LayoutBuilder(
      builder: (context, restricciones) {
        final columnas = restricciones.maxWidth >= 560 ? 4 : 2;
        const separacion = 12.0;
        final ancho =
            (restricciones.maxWidth - separacion * (columnas - 1)) / columnas;
        return Wrap(
          spacing: separacion,
          runSpacing: separacion,
          children: [
            for (final t in tarjetas) SizedBox(width: ancho, child: t),
          ],
        );
      },
    );
  }

  Widget _alertas(_Resumen r) {
    if (r.alertas.isEmpty) {
      return const Card(
        margin: EdgeInsets.zero,
        child: ListTile(
          leading: Icon(Icons.check_circle_outline, color: AppTheme.ok),
          title: Text('Todo al día'),
          subtitle: Text('No hay préstamos vencidos ni por vencer.'),
        ),
      );
    }

    final visibles = r.alertas.take(3).toList();
    return Column(
      children: [
        for (final d in visibles)
          Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              title: Text(d.tituloLibro),
              subtitle: Text(d.nombreEstudiante),
              trailing: EstadoChip.dePrestamo(d.prestamo),
            ),
          ),
        if (r.alertas.length > visibles.length)
          Align(
            alignment: Alignment.centerLeft,
            child: Text('y ${r.alertas.length - visibles.length} más…'),
          ),
      ],
    );
  }
}
