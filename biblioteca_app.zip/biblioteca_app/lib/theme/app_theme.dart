import 'package:flutter/material.dart';

/// Tema visual único de la aplicación (Material 3).
///
/// Centralizar colores y formas aquí garantiza un diseño coherente en todas
/// las pantallas: ninguna pantalla define sus propios colores sueltos.
class AppTheme {
  AppTheme._();

  /// Verde institucional usado como semilla de toda la paleta.
  static const Color semilla = Color(0xFF1B5E4A);

  // Colores semánticos para los estados (contraste AA sobre fondo claro).
  static const Color ok = Color(0xFF1E6B26);
  static const Color aviso = Color(0xFF8A5300);
  static const Color peligro = Color(0xFFB3261E);
  static const Color neutro = Color(0xFF49454F);

  static ThemeData claro() {
    final esquema = ColorScheme.fromSeed(seedColor: semilla);
    return ThemeData(
      useMaterial3: true,
      colorScheme: esquema,
      appBarTheme: AppBarTheme(
        backgroundColor: esquema.primary,
        foregroundColor: esquema.onPrimary,
        centerTitle: false,
      ),
    );
  }
}
